package com.kh.statement.run;

import com.kh.statement.view.EmployeeView;

public class EmployeeRun {

	public static void main(String[] args) {

		EmployeeView ev = new EmployeeView();
		ev.mainMenu();
	}

}
